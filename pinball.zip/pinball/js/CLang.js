var TEXT_PRELOADER_CONTINUE = "START";
var TEXT_ARE_SURE = "ARE YOU SURE?";
var TEXT_PAUSE = "PAUSE";

var TEXT_HELP1     = "USE KEYS TO MOVE THE FLIPPERS AND LAUNCH THE BALL";
var TEXT_HELP2     = "TRY TO DO AS MANY POINTS AS POSSIBLE!";
var TEXT_HELP1_MOBILE = "CLICK ON THE LEFT OR RIGHT SIDE OF THE SCREEN TO MOVE THE FLIPPERS ACCORDINGLY";

var TEXT_IOS_PRIVATE = 'Your web browser does not support storing settings locally. In Safari, the most common cause of this is using "Private Browsing Mode". Some info may not save or some features may not work properly';
var TEXT_DEVELOPED = "DEVELOPED BY";

var TEXT_MULTI = "MULTI";
var TEXT_SHIELD = "SHIELD";
var TEXT_EXTRABALL = "EXTRA BALL";
var TEXT_HOLE_VALUE = ["1K", "5K", "10K", "50K", "100K", "500K", "1M"];
var TEXT_ROUTER_VALUE = ["50", "100", "200", "500", "1k", "2k", "5k"];

var TEXT_SHARE_IMAGE = "200x200.jpg";
var TEXT_SHARE_TITLE = "Congratulations!";
var TEXT_SHARE_MSG1 = "You collected <strong>";
var TEXT_SHARE_MSG2 = " points</strong>!<br><br>Share your score with your friends!";
var TEXT_SHARE_SHARE1 = "My score is ";
var TEXT_SHARE_SHARE2 = " points! Can you do better";